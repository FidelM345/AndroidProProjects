package com.fidelomolokucu.kucuapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.CardView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class Appmain extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener,View.OnClickListener {
    CardView card_Committee,card_Programs,card_Sermons,card_Resources,card_Events,
            card_Staff,card_Gallery,card_Blog;
    Animation fromBottom,fromSide;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appmain);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG).setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        fromBottom= AnimationUtils.loadAnimation(this,R.anim.frombottom);



        cardClickListener();




    }

    private void cardClickListener() {
        //referencing cardviews
        card_Committee=findViewById(R.id.Committee_card);
        card_Blog=findViewById(R.id.Blog_card);
        card_Events=findViewById(R.id.Events_card);
        card_Programs=findViewById(R.id.Programs_card);
        card_Gallery=findViewById(R.id.Gallery_card);
        card_Staff=findViewById(R.id.Staff_card);
        card_Resources=findViewById(R.id.Resource_card);
        card_Sermons=findViewById(R.id.Sermons_card);

        card_Committee.setAnimation(fromBottom);

        card_Committee.setAnimation(fromBottom);
        card_Committee.setOnClickListener(this);
        card_Programs.setOnClickListener(this);
        card_Committee.setOnClickListener(this);
        card_Resources.setOnClickListener(this);
        card_Events.setOnClickListener(this);
        card_Staff.setOnClickListener(this);
        card_Gallery.setOnClickListener(this);
        card_Blog.setOnClickListener(this);




    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.appmain, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        /*if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }*/

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.Committee_card:
                Intent i=new Intent(getApplicationContext(),Committe.class);
                startActivity(i);

                break;
            case R.id.Programs_card:
                Intent in=new Intent(getApplicationContext(),Committe.class);
                startActivity(in);

                break;
            case R.id.Sermons_card:
                Intent in1=new Intent(getApplicationContext(),Committe.class);
                startActivity(in1);

                break;

            case R.id.Resource_card:
                Intent in2=new Intent(getApplicationContext(),Committe.class);
                startActivity(in2);

                break;

            case R.id.Events_card:
                Intent in3=new Intent(getApplicationContext(),LocationTest.class);
                startActivity(in3);

                break;
            case R.id.Staff_card:
                Intent in4=new Intent(getApplicationContext(),Committe.class);
                startActivity(in4);

                break;

            case R.id.Gallery_card:
                Intent in5=new Intent(getApplicationContext(),Committe.class);
                startActivity(in5);

                break;

            case R.id.Blog_card:
                Intent in6=new Intent(getApplicationContext(),Committe.class);
                startActivity(in6);

                break;


            default:
                break;

        }



    }
}
