package com.fidelomolokucu.kucuapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.fidelomolokucu.kucuapp.Model.EventPost;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import id.zelory.compressor.Compressor;

public class Main2Activity extends AppCompatActivity {

    AlertDialog.Builder builder;
    View view1;
    ImageView exit_btn,event_photo;
    FloatingActionButton fab;
    AlertDialog alert_cancel_id;
    FirebaseFirestore firestore;
    AppCompatEditText title,description;
    Button post_btn1;

    Uri mainImageUri = null;
    ProgressBar progressBar;
    StorageReference firebaseStorage;
    Bitmap compressedImageBitmap;
    String text_title="dsdsd",text_description,thumb_uri,image_uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Post Events");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //alert dialog initialization
        builder=new AlertDialog.Builder(Main2Activity.this);
        fab = findViewById(R.id.add_float_btn);


        firestore=FirebaseFirestore.getInstance();
        firebaseStorage = FirebaseStorage.getInstance().getReference();

        fabButtonClick();

    }





    void fabButtonClick(){




        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                view1= LayoutInflater.from(Main2Activity.this).inflate(R.layout.post_interface,null);
                exit_btn=view1.findViewById(R.id.post_exit_btn);

                builder.setView(view1);
                alert_cancel_id=builder.show();

                exit_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        alert_cancel_id.cancel();//dismmisses the alert dialog
                        Toast.makeText(Main2Activity.this,"i am working",Toast.LENGTH_LONG).show();

                    }
                });

                event_photo=view1.findViewById(R.id.event_photo);

                event_photo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //do the following when image is clicked
                        aurtherImagePicker(); //method used for picking images easily
                        Toast.makeText(Main2Activity.this,"i am working",Toast.LENGTH_LONG).show();

                    }
                });


                post_btn1=view1.findViewById(R.id.post_btn);
                progressBar=view1.findViewById(R.id.progressBar);
                progressBar.setVisibility(View.INVISIBLE); title=view1.findViewById(R.id.event_title);

                title=view1.findViewById(R.id.event_title);


                description=view1.findViewById(R.id.event_description);

                post_btn1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        text_title=title.getText().toString();
                        text_description=description.getText().toString();

                        progressBar.setVisibility(View.VISIBLE);
                        Toast.makeText(Main2Activity.this,"the image url="+text_description,Toast.LENGTH_LONG).show();
                        storageFirebase();
                    }
                });
            }
        });
    }

    void storageFirebase(){
        if(!TextUtils.isEmpty(text_title)&& !TextUtils.isEmpty(text_description)&& mainImageUri !=null) {
            final String randomBlogName= UUID.randomUUID().toString();//generates random strings

            final StorageReference storageReference=firebaseStorage.child("Event_images/event_photo").child(randomBlogName+".jpg");

            storageReference.putFile(mainImageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                    if(task.isSuccessful()){


                        image_uri=task.getResult().getDownloadUrl().toString();

                        File actualImageFile=new File(mainImageUri.getPath());


                        try {
                            compressedImageBitmap = new Compressor(Main2Activity.this)
                                    //compressing image of high quality to a thumbnail bitmap for faster loading
                                    .setMaxWidth(100)
                                    .setMaxHeight(50)
                                    .setQuality(5)
                                    .setCompressFormat(Bitmap.CompressFormat.WEBP)
                                    .compressToBitmap(actualImageFile);


                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        //compressing image of high quality to a thumbnail bitmap for faster loading
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        compressedImageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                        byte[] data = baos.toByteArray();

                        UploadTask thumbfilepath=firebaseStorage.child("Event_images/event_thumbs").child(randomBlogName+".jpg").putBytes(data);

                        thumbfilepath.addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                                if(task.isSuccessful()){
                                    //after the image thumbnail has been uploaded successfully to the cloud storage
                                    //it publishes the contents to the firestore cloud storage
                                    forumDatabasepublish(task,text_title,text_description,image_uri);




                                }
                                else{
                                    String exception=task.getException().getMessage();

                                    Toast.makeText(Main2Activity.this, "Thumb Error is: "+exception, Toast.LENGTH_LONG).show();


                                }
                            }
                        });

                    }else {
                        String exception=task.getException().getMessage();

                        Toast.makeText(Main2Activity.this, "Image Error is: "+exception, Toast.LENGTH_LONG).show();



                    }


                }
            });

        }else{
            Toast.makeText(Main2Activity.this,"Please fill all Text fields",Toast.LENGTH_LONG).show();

        }

    }

    private void forumDatabasepublish(Task<UploadTask.TaskSnapshot> task, String text_title, String text_description, String image_uri) {

       thumb_uri=task.getResult().getDownloadUrl().toString();//gets the thumbnail url

        EventPost eventPost=new EventPost();

        eventPost.setTitle(text_title);
        eventPost.setDescription(text_description);
        eventPost.setImage_uri(image_uri);
        eventPost.setThumb_uri(thumb_uri);
        eventPost.setTimestamp(timeStamp());


        firestore.collection("event_posts").add(eventPost)
                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if(task.isSuccessful()){
                            progressBar.setVisibility(View.INVISIBLE);
                            Toast.makeText(Main2Activity.this,"Contents have been saved Successfully",Toast.LENGTH_LONG).show();
                            alert_cancel_id.dismiss();//dismisses alert dialog after the contents have been posted to the db

                        }
                        else{
                          String error= task.getException().getMessage().toString();
                          Toast.makeText(Main2Activity.this,"Error is: "+error,Toast.LENGTH_LONG).show();

                        }
                    }
                });




    }


    private long timeStamp() {
        Long timestamp=System.currentTimeMillis()/1000;
        return timestamp;
    }

    private void aurtherImagePicker() {

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            //checks whether the os version is android 6 and above

            if(ContextCompat.checkSelfPermission(Main2Activity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
                // if the permission has been denied allow user to request for the permission
                ActivityCompat.requestPermissions(Main2Activity.this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},1);
            }else{

                //if permission has been granted do the bellow
                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(4,3)
                        .setActivityTitle("Event Photo Upload")
                        .setScaleType(CropImageView.ScaleType.FIT_CENTER)
                        //.setMinCropResultSize(512,512)
                        .start(this);
            }


        }else{
            //do the following if the android OS is less than mashmellow or android 6.0
            CropImage.activity()
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1,1)
                    .start(this);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage. getActivityResult(data);
            if (resultCode == RESULT_OK) {

                mainImageUri= result.getUri();
                event_photo.setImageURI(mainImageUri);
            }  else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {

                Exception error = result.getError();
                Toast.makeText(this, "Cropper error"+error, Toast.LENGTH_LONG).show();

            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode==1){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){

                //we use an array of index number 0 because only one permission ise being requested
                //this method is called so that one the permission is granted for the first time then the code on the else block will execute immediately
                //helps yo not to preee the button twice inorder to make the phone call
                aurtherImagePicker();

            }else {

                Toast.makeText(this, "Permission Denied", Toast.LENGTH_LONG).show();
            }
        }
    }
}
