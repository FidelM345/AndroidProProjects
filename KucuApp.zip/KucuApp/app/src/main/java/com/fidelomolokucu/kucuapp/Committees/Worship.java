package com.fidelomolokucu.kucuapp.Committees;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.fidelomolokucu.kucuapp.R;

public class Worship extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_worship);

    }
}
