package com.fidelomolokucu.kucuapp;

import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class LocationTest extends AppCompatActivity {
    TextView latitude,longitude;
    Button button;
    private FusedLocationProviderClient fusedLocationClient;
    String lat,lon;
    private  static final int REQUEST_CHECK_SETTINGS=200;
    LocationManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_test);

        latitude=findViewById(R.id.id_lat);
        longitude=findViewById(R.id.id_long);

         fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
         manager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);


    }

    @Override
    protected void onStart() {
        super.onStart();

        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER) && !manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {

            Toast.makeText(this, "Enable location services for accurate data", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(this,Appmain.class);
            startActivity(intent);

        }


    }

    public void getLocation(View view) {
        checkLocationPermission();
        //TODO:has internet->submit to db
        fusedLocationClient.getLastLocation().addOnSuccessListener(LocationTest.this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    //location available
                    //lat = String.valueOf(location.getLatitude());//latitude of user
                    lat=String.valueOf(location.getLatitude()).isEmpty() ?"0":String.valueOf(location.getLatitude());
                    //lon = String.valueOf(location.getLongitude());//longitude
                    lon=String.valueOf(location.getLongitude()).isEmpty() ?"0":String.valueOf(location.getLongitude());

                    latitude.setText(lat);
                    longitude.setText(lon);

                }else{

                }
                }

        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(LocationTest.this,"The location error "+e.getMessage().toString(),Toast.LENGTH_LONG).show();

                Toast.makeText(LocationTest.this,"The location is null",Toast.LENGTH_LONG).show();

                if (e instanceof ResolvableApiException) {
                    // Location settings are not satisfied, but this can be fixed
                    // by showing the user a dialog.
                    try {
                        // Show the dialog by calling startResolutionForResult(),
                        // and check the result in onActivityResult().
                        ResolvableApiException resolvable = (ResolvableApiException) e;
                        resolvable.startResolutionForResult(LocationTest.this,
                                REQUEST_CHECK_SETTINGS);
                    } catch (IntentSender.SendIntentException sendEx) {
                        // Ignore the error.
                    }
                }

            }
        });
    }

    private boolean checkLocationPermission() {
        boolean permissionGranted = ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if(permissionGranted){
            //permission granted
            return true;
        }else{
            //permission NOT granted
            ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, 200);
            return false;
        }
    }
}
