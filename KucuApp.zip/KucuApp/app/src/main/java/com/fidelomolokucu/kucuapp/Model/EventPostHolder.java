package com.fidelomolokucu.kucuapp.Model;


import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;

public class EventPostHolder extends ViewHolder {


    public EventPostHolder(View itemView) {
        super(itemView);
    }
}
