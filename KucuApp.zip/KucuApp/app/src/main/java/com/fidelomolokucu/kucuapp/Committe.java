package com.fidelomolokucu.kucuapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ListAdapter;

import com.fidelomolokucu.kucuapp.Adapters.Choices_Adapter;

import java.util.List;

public class Committe extends AppCompatActivity {
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_committe);
        Toolbar toolbar = (Toolbar) findViewById(R.id.blood_toolbar);
        toolbar.setTitle("KUCU Committees");
        setSupportActionBar(toolbar);


        toolbar.setNavigationIcon(R.mipmap.back_arrow);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Appmain.class));
            }
        });


        String[]description=getResources().getStringArray(R.array.committee_names);

        Integer[] imgid={
                R.drawable.camera,
                R.drawable.commitees,
                R.drawable.events,
                R.drawable.sermons, R.drawable.commitees,
                R.drawable.events,
                R.drawable.sermons
        };

        Choices_Adapter choices_adapter=new Choices_Adapter(description,imgid);

        recyclerView=findViewById(R.id.blog_recycler_view);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setAdapter(choices_adapter);

    }



}
