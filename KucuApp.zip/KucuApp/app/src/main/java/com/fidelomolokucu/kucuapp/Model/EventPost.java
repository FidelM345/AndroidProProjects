package com.fidelomolokucu.kucuapp.Model;

public class EventPost {
    String title;
    String description;
    String thumb_uri;
    String image_uri;
    Long timestamp;

    public EventPost() {
    }

    public EventPost(String title, String description, String thumb_uri, String image_uri, Long timestamp) {
        this.title = title;
        this.description = description;
        this.thumb_uri = thumb_uri;
        this.image_uri = image_uri;
        this.timestamp = timestamp;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getThumb_uri() {
        return thumb_uri;
    }

    public void setThumb_uri(String thumb_uri) {
        this.thumb_uri = thumb_uri;
    }

    public String getImage_uri() {
        return image_uri;
    }

    public void setImage_uri(String image_uri) {
        this.image_uri = image_uri;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}
