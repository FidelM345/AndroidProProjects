package com.fidelomolokucu.kucuapp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.fidelomolokucu.kucuapp.Committees.Worship;
import com.fidelomolokucu.kucuapp.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class Choices_Adapter extends RecyclerView.Adapter<Choices_Adapter.ViewHolder> {


    String[]description;
    Integer[]imgid;
    Context context;


    public Choices_Adapter(String[] description, Integer[] imgid) {
        this.description = description;
        this.imgid = imgid;
    }

    @NonNull
    @Override
    public Choices_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //it inflates the custom made Layout file for list items
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_view,parent,false);
        context=parent.getContext();


        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Choices_Adapter.ViewHolder holder, final int position) {

        holder.profile_name.setText(description[position]);

        holder.profile_pic.setImageResource(imgid[position]);

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(position==0){
                    Intent intent=new Intent(context,Worship.class);
                    context.startActivity(intent);


                }else if(position==1){
                    //Do whatever you want here
                    Intent intent=new Intent(context,Worship.class);
                    context.startActivity(intent);

                }else if(position==2){

                }else if(position==3){

                }
            }
        });


    }

    @Override
    public int getItemCount() {

        return imgid.length;
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView profile_name;
        CircleImageView profile_pic;
        LinearLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);

            profile_pic=itemView.findViewById(R.id.profile_image1);
            profile_name=itemView.findViewById(R.id.committee_name);
            linearLayout=itemView.findViewById(R.id.linear_main);

        }




    }
}
